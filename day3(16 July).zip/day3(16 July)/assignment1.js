var a=prompt("enter number");
a=Number(a);
function check(num){
    if (num%2==0){
        var a="number is even";
        console.log(a);
    }else{
        a="number is odd";
        console.log(a);
    }
}
check(a);