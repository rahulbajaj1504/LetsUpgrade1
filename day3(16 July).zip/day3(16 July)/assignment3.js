// var a=prompt("enter marks");
// a=Number(a);
// if (a>70 && a<=100){
//     console.log("grade is A");
// }else if (a>40 && a<=70){
//     console.log("grade is B");
// }else if (a>0 && a<=40){
//     console.log("grade is C");
// }else{
//     console.log("enter marks from 100")
// }


var a=prompt("enter marks");
a=Number(a);
switch(true){
    case a>70 && a<=100:
        console.log("A");
        break;
    case a>40 && a<=70:
        console.log("B");
        break;
    case a>0 && a<=40:
        console.log("C");
        break;
    default:
        console.log("enter from from 100")
}