var a=prompt("enter OS name and version");
b=a.split(" ");
console.log("the OS name is",b[0],"and version is",b[1]);
